package co.edu.unbosque.view;

import javax.swing.JFrame;

import co.edu.unbosque.controller.Controller;

public class FrameP extends JFrame {

	PInicial pi;
	PDatosEmpleado pde;
	PDatosCliente pdc;
	Controller c;

	public FrameP(Controller co) {
		c = co;
		iniciarPaneles();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		setSize(995, 515);
		setResizable(false);
		setVisible(true);
		setLocationRelativeTo(null);
	}

	private void iniciarPaneles() {
		pi = new PInicial(this, c);
		pi.setVisible(true);
		add(pi);

		pde = new PDatosEmpleado(this, c);
		pde.setVisible(false);
		add(pde);

		pdc = new PDatosCliente(this, c);
		pdc.setVisible(false);
		add(pdc);
	}

	/**
	 * @return the pdc
	 */
	public PDatosCliente getPdc() {
		return pdc;
	}

	/**
	 * @return the pi
	 */
	public PInicial getPi() {
		return pi;
	}

	/**
	 * @return the pde
	 */
	public PDatosEmpleado getPde() {
		return pde;
	}

}
