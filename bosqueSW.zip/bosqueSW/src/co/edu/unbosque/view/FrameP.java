package co.edu.unbosque.view;

import co.edu.unbosque.controller.Controller;
import javax.swing.JFrame;
/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
public class FrameP extends JFrame {

	PInicial pi;
	PDatosEmpleado pde;
	PDatosCliente pdc;
	Controller c;
/**
 * Este es el constructor del FrameP
 * @param co , es el controlador que usa FrameP
 */
	public FrameP(Controller co) {
		c = co;
		iniciarPaneles();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(null);
		setSize(995, 515);
		setResizable(false);
		setVisible(true);
		setLocationRelativeTo(null);
	}
	
	/**
	 * Este es el metodo que inicializa los paneles contenidos en FrameP
	 */

	private void iniciarPaneles() {
		pi = new PInicial(this, c);
		pi.setVisible(true);
		add(pi);

		pde = new PDatosEmpleado(this, c);
		pde.setVisible(false);
		add(pde);

		pdc = new PDatosCliente(this, c);
		pdc.setVisible(false);
		add(pdc);
	}

	/**
	 * Este metodo devuelve el valor 
	 * @return the pdc
	 */
	public PDatosCliente getPdc() {
		return pdc;
	}

	/**
	 * @return the pi
	 */
	public PInicial getPi() {
		return pi;
	}

	/**
	 * @return the pde
	 */
	public PDatosEmpleado getPde() {
		return pde;
	}

}
