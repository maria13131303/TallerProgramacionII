package co.edu.unbosque.view;
/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import co.edu.unbosque.controller.Controller;
import co.edu.unbosque.modelo.IngenieroJunior;
import co.edu.unbosque.modelo.Personal;

public class PDatosEmpleado extends JPanel implements ActionListener {

	FrameP f;
	JLabel fondo, titulo, fRegistrar, fCancelar, fEditar;
	JButton btnReg, btnCan, btnEdit;
	JTextField nom, ape, ced, dir, tel, email;
	JSpinner a�o, nivel;
	JComboBox tipoList;
	JRadioButton masculino, femenino;
	ButtonGroup sexo;
	Controller c;
	boolean registro = true;

	/**
	 * Este es el metodo constructor del PDatosEmpleado
	 * @param f , FrameP que inicializa y controla PDatosEmpleado
	 * @param co , Controlador que usa PDatosEmpleado
	 */
	public PDatosEmpleado (FrameP f, Controller co) {
		c = co;
		this.f = f;
		setLayout(null);
		setBounds(-5, 0, 995, 515);
		agregarComponentes();
	}

	/**
	 * Metodo que agrega los elementos del panel
	 */

	private void agregarComponentes() {

		nom = new JTextField();
		nom.setBounds(225, 145, 250, 35);
		add(nom);

		ape = new JTextField();
		ape.setBounds(670, 145, 250, 35);
		add(ape);

		ced = new JTextField();
		ced.setBounds(355, 205, 170, 35);
		add(ced);

		dir = new JTextField();
		dir.setBounds(705, 205, 215, 35);
		add(dir);

		tel = new JTextField();
		tel.setBounds(200, 265, 145, 35);
		add(tel); 

		email = new JTextField();
		email.setBounds(455, 265, 230, 35);
		add(email);

		Calendar c = Calendar.getInstance();
		int a�oActual = c.get(Calendar.YEAR);
		SpinnerModel q = new SpinnerNumberModel(2019,1902,a�oActual,1);
		a�o = new JSpinner(q);
		a�o.setBounds(360, 325, 80, 35);
		JFormattedTextField r1 = ((JSpinner.DefaultEditor) a�o.getEditor()).getTextField();
		r1.setEditable(false);
		add (a�o);

		String[] tipoStrings = { "--SELECCIONE TIPO--", "Empleado por comision", "Ingeniero Senior", "Ingeniero Junior" };

		tipoList = new JComboBox();
		tipoList.addItem("--SELECCIONE TIPO--");
		tipoList.addItem("Empleado por comision");
		tipoList.addItem("Ingeniero Senior");
		tipoList.addItem("Ingeniero Junior");
		tipoList.setSelectedIndex(0);
		tipoList.addActionListener(this);
		tipoList.setBounds(680, 325, 160, 35);
		add(tipoList);

		SpinnerModel w = new SpinnerNumberModel(1,1,5,1);
		nivel = new JSpinner(w);
		nivel.setBounds(885, 325, 30, 35);
		JFormattedTextField r2 = ((JSpinner.DefaultEditor) nivel.getEditor()).getTextField();
		r2.setEditable(false);
		nivel.setVisible(false);
		add (nivel);

		masculino = new JRadioButton();
		masculino.setBounds(820, 262, 40, 40);
		masculino.setContentAreaFilled(false);
		masculino.setBorderPainted(false);
		add(masculino);

		femenino = new JRadioButton();
		femenino.setBounds(884, 262, 40, 40);
		femenino.setContentAreaFilled(false);
		femenino.setBorderPainted(false);
		add(femenino);

		sexo = new ButtonGroup();
		sexo.add(masculino);
		sexo.add(femenino);

		btnEdit = new JButton();
		btnEdit.setBounds(845, 17, 140, 40);
		btnEdit.setContentAreaFilled(false);
		btnEdit.setBorderPainted(false);
		btnEdit.addActionListener(this);
		btnEdit.setActionCommand("edit");
		add(btnEdit);

		ImageIcon iconEdit = new ImageIcon("data/editar.png");
		fEditar = new JLabel(iconEdit);
		fEditar.setBounds(825, 10, 180, 53);
		add(fEditar);

		btnReg = new JButton();
		btnReg.setBounds(260, 394, 220, 55);
		btnReg.setContentAreaFilled(false);
		btnReg.setBorderPainted(false);
		btnReg.addActionListener(this);
		btnReg.setActionCommand("reg");
		add(btnReg);

		ImageIcon iconReg = new ImageIcon("data/registrar.png");
		fRegistrar = new JLabel(iconReg);
		fRegistrar.setBounds(250, 384, 240, 74);
		add(fRegistrar);

		btnCan = new JButton();
		btnCan.setBounds(520, 394, 220, 55);
		btnCan.setContentAreaFilled(false);
		btnCan.setBorderPainted(false);
		btnCan.addActionListener(this);
		btnCan.setActionCommand("can");
		add(btnCan);

		ImageIcon iconCan = new ImageIcon("data/cancelar.png");
		fCancelar = new JLabel(iconCan);
		fCancelar.setBounds(510, 384, 240, 74);
		add(fCancelar);

		titulo = new JLabel();
		titulo.setBounds(0, 0, 1000, 495);
		add(titulo);

		ImageIcon fon = new ImageIcon("data/fondoDatosO.png");
		fondo = new JLabel(fon);
		fondo.setBounds(0, 0, 1000, 495);
		add(fondo);
	}

	/**
	 * Metodo que oculta el boton de editar perfil
	 */

	public void ocultarEdit () {
		fEditar.setVisible(false);
		btnEdit.setVisible(false);
	}

	/**
	 * Metodo que vacia los campos de datos para el empleado
	 */

	public void limpiar () {
		nom.setText("");
		ape.setText("");
		ced.setText("");
		dir.setText("");
		tel.setText("");
		email.setText("");
		sexo.clearSelection();
		tipoList.setSelectedIndex(0);
	}

	/**
	 * Metodo que muestra los campos llenos de un perfil ya creado
	 * <b> pre </b> Ya ha sido creado al menos un objeto Personal 
	 * <b> post </b> Muestra los atributos de un objeto Personal
	 * @param pced , Es la cedula del objeto Personal
	 */

	public void mostrarEdit (String pced) {
		desbloquearItems();
		nivel.setEnabled(true);
		fEditar.setVisible(true);
		String buscado;
		buscado = pced.substring(0, 10);
		System.out.println(buscado);
		Personal p = c.buscarPersonal(buscado);

		nom.setText(p.getNombre());
		nom.setEditable(false);
		ape.setText(p.getApellido());
		ape.setEditable(false);
		ced.setText(p.getCedula());
		ced.setEditable(false);
		dir.setText(p.getDireccion());
		dir.setEditable(false);
		tel.setText(p.getTelefono());
		tel.setEditable(false);
		email.setText(p.getCorreo());
		email.setEditable(false);
		a�o.setValue(p.getAnioActual()-p.getAnio());
		a�o.setEnabled(false);
		masculino.setEnabled(false);
		femenino.setEnabled(false);
		
		char s = p.getGenero();
		if (s == 'M') {
			masculino.setSelected(true);
		} else {
			femenino.setSelected(true);
		}
		String clase = p.getClass().toString();
		switch(clase)
		{
		case "class co.edu.unbosque.modelo.PersonalComision":
			tipoList.setSelectedIndex(1);
			break;
		case "class co.edu.unbosque.modelo.IngenieroJunior":
			IngenieroJunior ij = (IngenieroJunior)(p);
			tipoList.setSelectedIndex(3);
			nivel.setValue(ij.getNivel());
			break;
		case "class co.edu.unbosque.modelo.IngenieroSenior":
			tipoList.setSelectedIndex(2);
			break;
		}
		tipoList.setEnabled(false);
		nivel.setEnabled(false);
		btnEdit.setVisible(true);
	}

	/**
	 *  Este metodo deshabilita el boton actualizar perfil
	 */

	public void deshabilitar () {
		ImageIcon iconActb = new ImageIcon("data/actualizarb.png");
		fRegistrar.setIcon(iconActb);
	}

	/**
	 * Este metodo permite editar los campos que han sido cargados con los atributos del objeto Personal
	 */

	public void desbloquearItems()
	{
		nom.setEditable(true);
		ape.setEditable(true);
		dir.setEditable(true);
		tel.setEditable(true);
		email.setEditable(true);
		a�o.setEnabled(true);
		tipoList.setEditable(true);
		nivel.setEnabled(true);
		btnEdit.setVisible(true);
        masculino.setEnabled(true);
        femenino.setEnabled(true);
	}
	
	public void activarCeldasRestringidas()
	{
		ced.setEditable(true);
		tipoList.setEditable(false);
		tipoList.setEnabled(true);
	}

	/**
	 * Este metodo controla las accciones que resultan de eventos
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		String accion = arg0.getActionCommand();

		if (accion == "reg") {
			
			char sexo = 0;
			if (masculino.isSelected()) {
				sexo= 'M';
			} else if (femenino.isSelected()) {
				sexo = 'F';
			}

			if (registro == true) {
				System.out.println("Registrar");
					try {
						if (tipoList.getSelectedIndex()==0) {
							throw new Exception("Indique el tipo de cliente a registrar");
						}
						c.agregarPersonal(tipoList.getSelectedIndex(),ced.getText(), ape.getText(), nom.getText(), tel.getText(), email.getText(), dir.getText(), (int)(a�o.getValue()), sexo, (int)nivel.getValue());
						f.getPi().actualizarLista();
						btnCan.doClick();
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, e.getMessage());
					}
				} 
				else if (registro == false) {
					try {
						char sex = 0;
						if (masculino.isSelected()) {
							sex= 'M';
						} else if (femenino.isSelected()) {
							sex = 'F';
						}
						c.editarPersonal(tipoList.getSelectedIndex(),ced.getText(), ape.getText(), nom.getText(), tel.getText(), email.getText(), dir.getText(), (int)(a�o.getValue()), sex, (int)nivel.getValue());
						f.getPi().actualizarLista();
						btnCan.doClick();
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, e.getMessage());
					}
				}
		}

		if (accion == "can") {
			f.getPde().setVisible(false);
			f.setTitle("BosqueSW");
			f.getPi().bloquear();
			f.getPi().setVisible(true);
			deshabilitar();
			limpiar(); 
			registro = true;
		}

		if (accion == "edit") {	
			System.out.println("edit");
			ImageIcon iconAct = new ImageIcon("data/actualizar.png");
			fRegistrar.setIcon(iconAct);
			desbloquearItems();
			ocultarEdit();
			btnReg.setVisible(true);
			registro = false;
		}

		String opcion = (String)tipoList.getSelectedItem();
		if (opcion == "Ingeniero Junior") {
			ImageIcon fon = new ImageIcon("data/fondoDatosJunior.png");
			fondo.setIcon(fon);
			a�o.setBounds(285, 325, 80, 35);
			tipoList.setBounds(580, 325, 160, 35);
			nivel.setVisible(true);
		} else {
			ImageIcon fon = new ImageIcon("data/fondoDatosO.png");
			fondo.setIcon(fon);
			a�o.setBounds(360, 325, 80, 35);
			tipoList.setBounds(680, 325, 160, 35);
			nivel.setVisible(false);
		}
	}
}