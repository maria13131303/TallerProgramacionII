package co.edu.unbosque.view;
import java.awt.Font;
/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import co.edu.unbosque.controller.Controller;
import co.edu.unbosque.modelo.IngenieroJunior;
import co.edu.unbosque.modelo.Personal;

public class PDatosCliente extends JPanel implements ActionListener {

	FrameP f;
	JLabel fondo, fRegistrar, fCancelar;
	JButton btnReg, btnCan;
	JTextField nom, ape, ced, mon;
	JComboBox vendedorList;
	Controller c;
	public PDatosCliente (FrameP f, Controller co) {
		c = co;
		this.f = f;
		setLayout(null);
		setBounds(-5, 0, 755, 515);
		agregarComponentes();
	}
	
	/**
	 * Este metodo agrega los elementos del panel
	 */
	private void agregarComponentes() {

		nom = new JTextField();
		nom.setBounds(335, 145, 350, 35);
		add(nom);
		
		ape = new JTextField();
		ape.setBounds(335, 205, 350, 35);
		add(ape);
		
		ced = new JTextField();
		ced.setBounds(455, 265, 230, 35);
		add(ced);
		
		mon = new JTextField();
		mon.setBounds(525, 325, 160, 35);
		add(mon);
		
		vendedorList = new JComboBox();
		String cedula;
		vendedorList.setBounds(220, 325, 180, 35);
		vendedorList.setFont(new Font("ArialBlack",1,15));
		vendedorList.removeAll();
		for (int i = 0; i < c.getPersonal().size(); i++) {
			cedula = c.getPersonal().get(i).getCedula();
			Personal p = c.buscarPersonal(cedula);
			String clase = p.getClass().toString();
			if(clase.equals("class co.edu.unbosque.modelo.PersonalComision"))
			{
				vendedorList.addItem(p.getCedula());
			}
		}
		
		
		add(vendedorList);
		
		btnReg = new JButton();
		btnReg.setBounds(130, 384, 240, 74);
		btnReg.setContentAreaFilled(false);
		btnReg.setBorderPainted(false);
		btnReg.addActionListener(this);
		btnReg.setActionCommand("reg");
		add(btnReg);

		ImageIcon iconReg = new ImageIcon("data/registrar.png");
		fRegistrar = new JLabel(iconReg);
		fRegistrar.setBounds(130, 384, 240, 74);
		add(fRegistrar);

		btnCan = new JButton();
		btnCan.setBounds(400, 394, 220, 55);
		btnCan.setContentAreaFilled(false);
		btnCan.setBorderPainted(false);
		btnCan.addActionListener(this);
		btnCan.setActionCommand("can");
		add(btnCan);

		ImageIcon iconCan = new ImageIcon("data/cancelar.png");
		fCancelar = new JLabel(iconCan);
		fCancelar.setBounds(390, 384, 240, 74);
		add(fCancelar);
		
		ImageIcon iconFon = new ImageIcon("data/fondoDatosCliente.png");
		fondo = new JLabel(iconFon);
		fondo.setBounds(0, 0, 760, 495);
		add(fondo);
	}
	
	public void limpiar () {
		nom.setText("");
		ape.setText("");
		ced.setText("");
		mon.setText("");
	}
	/**
	 * Este metodo controla las accciones que resultan de eventos
	 */

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String accion = arg0.getActionCommand();
		if(this.isVisible())
		{
			String cedula;
			vendedorList.removeAll();
			for (int i = 0; i < c.getPersonal().size(); i++) {
				cedula = c.getPersonal().get(i).getCedula();
				Personal p = c.buscarPersonal(cedula);
				String clase = p.getClass().toString();
				if(clase.equals("class co.edu.unbosque.modelo.PersonalComision"))
				{
					vendedorList.addItem(p.getCedula());
				}
			}
		}
		if (accion == "can") {
			f.getPdc().setVisible(false);
			f.setSize(995, 515);
			f.setLocationRelativeTo(null);
			f.setTitle("BosqueSW");
			f.getPi().setVisible(true);
			limpiar();
		}
		if (accion == "reg") {
			c.asignarCliente(vendedorList.getName(), nom.getText()+" "+ape.getText(), ced.getText(),  Double.valueOf(mon.getText()));
			btnCan.doClick();
		}
	}
}
