package co.edu.unbosque.view;
/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
import java.awt.Font;
import java.awt.Image;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.text.IconView;

import co.edu.unbosque.controller.Controller;
import co.edu.unbosque.modelo.IngenieroJunior;
import co.edu.unbosque.modelo.IngenieroSenior;
import co.edu.unbosque.modelo.PersonalComision;

public class PInicial extends JPanel implements ActionListener {

	FrameP f;
	JLabel fondo, fVer, fDespedir, fCon, fAgrE, fAgrC, fEliC, fRestaurar;
	JButton btnVer, btnDes, btnCon, btnAgrE, btnAgrC, btnEliC, btnRes;
	List lista;
	Controller c;
/**
 * Esta es la clase PanelInicial que muestra los elementos de la primera ventana de la vista
 * @param f , FrameP donde han sido inicializados y controla los paneles 
 * @param co , 
 */
	public PInicial (FrameP f, Controller co) {
		c = co;
		this.f = f;
		setLayout(null);
		setBounds(-5,0,995,515);
		setVisible(true);
		agregarComponentes();
		bloquear();
	}

	private void agregarComponentes() {

		lista = new List();
		String ape;
		String nom;
		String ced;
		lista.setBounds(50, 149, 500, 205);
		lista.setFont(new Font("ArialBlack",1,15));
		lista.addActionListener(this);
		for (int i = 0; i < c.getPersonal().size(); i++) {
			ced = c.getPersonal().get(i).getCedula();
			ape = c.getPersonal().get(i).getApellido();
			nom = c.getPersonal().get(i).getNombre();
			lista.add(ced+"   "+ape+" "+nom);
		}
		lista.select(0);
		add(lista);

		btnVer = new JButton();
		btnVer.setBounds(660, 155, 200, 49);
		btnVer.setContentAreaFilled(false);
		btnVer.setBorderPainted(false);
		btnVer.addActionListener(this);
		btnVer.setActionCommand("ver");
		add(btnVer);

		fVer = new JLabel();
		fVer.setBounds(650, 145, 220, 69);
		add(fVer);

		btnDes = new JButton();
		btnDes.setBounds(660, 225, 200, 49);
		btnDes.setContentAreaFilled(false);
		btnDes.setBorderPainted(false);
		btnDes.addActionListener(this);
		btnDes.setActionCommand("des");
		add(btnDes);

		fDespedir = new JLabel();
		fDespedir.setBounds(650, 215, 220, 69);
		add(fDespedir);

		btnCon = new JButton();
		btnCon.setBounds(635, 295, 250, 49);
		btnCon.setContentAreaFilled(false);
		btnCon.setBorderPainted(false);
		btnCon.addActionListener(this);
		btnCon.setActionCommand("con");
		add(btnCon);

		fCon = new JLabel();
		fCon.setBounds(620, 285, 280, 69);
		add(fCon);

		btnAgrE = new JButton();
		btnAgrE.setBounds(51, 394, 220, 55);
		btnAgrE.setContentAreaFilled(false);
		btnAgrE.setBorderPainted(false);
		btnAgrE.addActionListener(this);
		btnAgrE.setActionCommand("agrE");
		add(btnAgrE);

		ImageIcon iconAgrE = new ImageIcon("data/fonAgregarE.png");
		fAgrE = new JLabel(iconAgrE);
		fAgrE.setBounds(41, 384, 240, 74);
		add(fAgrE);

		btnAgrC = new JButton();
		btnAgrC.setBounds(277, 394, 220, 55);
		btnAgrC.setContentAreaFilled(false);
		btnAgrC.setBorderPainted(false);
		btnAgrC.addActionListener(this);
		btnAgrC.setActionCommand("agrC");
		add(btnAgrC);

		ImageIcon iconAgrC = new ImageIcon("data/fonAgregarC.png");
		fAgrC = new JLabel(iconAgrC);
		fAgrC.setBounds(267, 384, 240, 74);
		add(fAgrC);

		btnEliC = new JButton();
		btnEliC.setBounds(503, 394, 220, 55);
		btnEliC.setContentAreaFilled(false);
		btnEliC.setBorderPainted(false);
		btnEliC.addActionListener(this);
		btnEliC.setActionCommand("eliC");
		add(btnEliC);

		ImageIcon iconEliC = new ImageIcon("data/fonEliminarC.png");
		fEliC = new JLabel(iconEliC);
		fEliC.setBounds(493, 384, 240, 74);
		add(fEliC);

		btnRes = new JButton();
		btnRes.setBounds(728, 394, 220, 55);
		btnRes.setContentAreaFilled(false);
		btnRes.setBorderPainted(false);
		btnRes.addActionListener(this);
		btnRes.setActionCommand("res");
		add(btnRes);

		ImageIcon iconRes = new ImageIcon("data/fonRestaurar.png");
		fRestaurar = new JLabel(iconRes);
		fRestaurar.setBounds(718, 384, 240, 74);
		add(fRestaurar);

		ImageIcon iconFondo = new ImageIcon("data/fondo.png");
		fondo = new JLabel(iconFondo);
		fondo.setBounds(0,0,1000,495);
		add(fondo);
	}
	
	public void actualizarLista()
	{
		String ced, ape, nom;
		lista.removeAll();
		for (int i = 0; i < c.getPersonal().size(); i++) {
			ced = c.getPersonal().get(i).getCedula();
			ape = c.getPersonal().get(i).getApellido();
			nom = c.getPersonal().get(i).getNombre();
			lista.add(ced+"   "+ape+" "+nom);
		}
	}

	public void bloquear () {
		ImageIcon iconVerb = new ImageIcon("data/fVerb.png");
		fVer.setIcon(iconVerb);
		btnVer.setVisible(false);

		ImageIcon iconDesb = new ImageIcon("data/fDesb.png");
		fDespedir.setIcon(iconDesb);
		btnDes.setVisible(false);

		ImageIcon iconConb = new ImageIcon("data/fConb.png");
		fCon.setIcon(iconConb);
		btnCon.setVisible(false);
	}

	public void desbloquear () {
		ImageIcon iconVer = new ImageIcon("data/fonVer.png");
		fVer.setIcon(iconVer);
		btnVer.setVisible(true);

		ImageIcon iconDes = new ImageIcon("data/fonDespedir.png");
		fDespedir.setIcon(iconDes);
		btnDes.setVisible(true);

		ImageIcon iconCon = new ImageIcon("data/fonConsulta.png");
		fCon.setIcon(iconCon);
		btnCon.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		String accion = arg0.getActionCommand();
		System.out.println(accion);

		if (lista.getSelectedItem() != null) {
			desbloquear(); 
		} else {
			bloquear();
		}

		if (accion == "ver") {
			f.getPi().setVisible(false);
			f.setTitle("BosqueSW - Ver Empleado");
			ImageIcon btn = new ImageIcon("data/actualizarb.png");
			f.getPde().fRegistrar.setIcon(btn);
			f.getPde().btnReg.setVisible(false);
			ImageIcon iconTit = new ImageIcon("data/tituloDatos.png");
			f.getPde().titulo.setIcon(iconTit);
			f.getPde().mostrarEdit(lista.getSelectedItem());
			f.getPde().setVisible(true);
		}

		if (accion == "des") {
			int dialogButton = JOptionPane.showConfirmDialog (null, "�Est� seguro de despedir este empleado?","ADVERTENCIA",JOptionPane.YES_NO_OPTION);
			if(dialogButton == JOptionPane.YES_OPTION) {
				System.out.println("Despedir");
				String ced = lista.getSelectedItem().substring(0, 10);
				c.eliminar(ced);
				actualizarLista();
			}
		}

		if (accion == "regV") {
			bloquear();
		}

		if (accion == "eliV") {
			bloquear();
		}

		if (accion == "con") {
			String pers = lista.getSelectedItem();
			String personal = pers.substring(0, 10);
			String clase = c.buscarPersonal(personal).getClass().toString();
			switch(clase)
			{
			case "class co.edu.unbosque.modelo.PersonalComision":
				PersonalComision pc = (PersonalComision)c.buscarPersonal(personal);
				JOptionPane.showMessageDialog(null, "El salario del empleado con cedula "+lista.getSelectedItem().substring(0, 10)+" es: $"+ pc.calcularSalario());
				break;
			case "class co.edu.unbosque.modelo.IngenieroJunior":
				IngenieroJunior ij = (IngenieroJunior)c.buscarPersonal(personal);
				JOptionPane.showMessageDialog(null, "El salario del empleado con cedula "+lista.getSelectedItem().substring(0, 10)+" es: $"+ ij.calcularSalario());
				break;
			case "class co.edu.unbosque.modelo.IngenieroSenior":
				IngenieroSenior is = (IngenieroSenior)c.buscarPersonal(personal);
				JOptionPane.showMessageDialog(null, "El salario del empleado con cedula "+lista.getSelectedItem().substring(0, 10)+" es: $"+ is.calcularSalario());
				break;
			}
			
		}

		if (accion == "agrE") {
			
			f.getPi().setVisible(false);
			f.setTitle("BosqueSW - Agregar Empleado");
			ImageIcon btn = new ImageIcon("data/registrar.png");
			f.getPde().fRegistrar.setIcon(btn);
			f.getPde().btnReg.setVisible(true);
			ImageIcon iconTit = new ImageIcon("data/tituloCompleta.png");
			f.getPde().titulo.setIcon(iconTit);
			f.getPde().ocultarEdit();
			f.getPde().activarCeldasRestringidas();
			f.getPde().setVisible(true);
			System.out.println("Agregar Empleado");
		}

		if (accion == "agrC") {
			f.getPi().setVisible(false);
			f.setSize(760, 495);
			f.setLocationRelativeTo(null);
			f.setTitle("BosqueSW - Agregar Cliente");
			f.getPdc().setVisible(true);
			System.out.println("Agregar Cliente");
			
		}

		if (accion == "eliC") {
			String CedVen = JOptionPane.showInputDialog(null, "Ingrese la cedula del vendedor:","Eliminar venta",JOptionPane.CANCEL_OPTION);
			String CedC = JOptionPane.showInputDialog(null, "Ingrese la cedula del cliente:","Eliminar venta",JOptionPane.CANCEL_OPTION);
			c.eliminarCliente(CedVen, CedC);
			System.out.println("Eliminar Cliente");
		}

		if (accion == "res") {
			int dialogButton = JOptionPane.showConfirmDialog (null, "�Est� seguro de borrar todos los datos del sistema?","ADVERTENCIA",JOptionPane.YES_NO_OPTION);
			if(dialogButton == JOptionPane.YES_OPTION) {
				c.borrarDatos();
				}
			System.out.println("Restaurar sistema");
		}
	}
}
