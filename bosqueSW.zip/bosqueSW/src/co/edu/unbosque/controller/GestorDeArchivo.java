package co.edu.unbosque.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import co.edu.unbosque.modelo.Personal;

public class GestorDeArchivo {
	ObjectInputStream entrada;
	ObjectOutputStream salida;
	ArrayList<Personal> personal;
	File archivo = new File("data/datos.dat");
	
	public GestorDeArchivo() {
		this.personal = new ArrayList<Personal>();
	}
	
	public ArrayList<Personal> cargarArchivo() {
		if(!archivo.exists()) 
		{
			try 
			{
				archivo.createNewFile();
			} catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
		else 
		{
			if(archivo.length()!=0){
				try 
				{
					entrada=new ObjectInputStream(new FileInputStream(archivo));
					personal=(ArrayList<Personal>)entrada.readObject();
				} 
				catch (IOException e) 
				{
					
				} 
				catch (ClassNotFoundException e) 
				{
					e.printStackTrace();
				}
			}
		}
		return personal;
	}
	
	public void guardarEnArchivo(ArrayList<Personal> personal)
	{
		try 
		{
			salida=new ObjectOutputStream(new FileOutputStream(archivo));
			salida.writeObject(personal);
			salida.close();
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public void reinicio()
	{
		archivo.delete();
		try {
			archivo.createNewFile();
			} catch (IOException ioe) {
			  ioe.printStackTrace();
			}
	}
	
	public void actualizar(ArrayList<Personal> personal)
	{
		reinicio();
		guardarEnArchivo(personal);
	}
}
