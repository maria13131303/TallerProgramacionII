package co.edu.unbosque.modelo;
/**
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
/**
 * Esta es la clase de Ingenierio Junior que hereda de Personal de salario Fijo
 */
public class IngenieroJunior extends PersonalSalarioFijo{
	int nivel;
	/**
	 * Este es el constructor 
	 * @param cedula , La cedula que le pondremos al personal  para identificarlo
	 * @param apellido, apellido que tendra nuestro personal
	 * @param nombre, nombre que tendra el personal
	 * @param telefono . telefono del personal
	 * @param correo , Correo que tendra el personal 
	 * @param direccion , Direccion que tendra el personal
	 * @param anioIngreso , A�o en el cual nuestro personal ingreso a la empresa
	 * @param genero , genero de nuestro personal
	 * @param nivel que tendra nuestro ingenierio va desde 1-5
	 */
	public IngenieroJunior(String cedula, String apellido, String nombre, String telefono, String correo,
			String direccion, int anioIngreso, char genero, int nivel) {
		super(cedula, apellido, nombre, telefono, correo, direccion, anioIngreso, genero);
		this.nivel = nivel;
	}
/**
 * Este es el metodo que nos ayuda a avanzar los niveles de el ingenierio
 */
	public void ascenso ()
	{
		nivel++;
	}
	/**
	 * Este es el metodo que nos ayuda a calcular el porcentaje adicional del salario
	 * Los  Ingenierios Junior Nivel 2 y 3 obtienen un 5% adicional a su sueldo base y los Junior Nivel 4 y 5 un 8% adicional
	 */
	public double  porcentajeAdicional(int num)
	{
		double porcentaje = 0;
		if (num==1) 
		{
			porcentaje = 0;
		}
		if (num==2&&num==3) 
		{
			porcentaje = 0.05;
		}
		if (num==4&&num==5) 
		{
			porcentaje = 0.08;
		}
		return porcentaje;
	}
	/**
	 * Este es  el metodo que nos ayuda a calcular el salario de los ingenierios junior
	 * Dependera de el porcentaje adicional
	 * <b>pre</b> Ya deben tener un salario base para poder calcular el salario final
	 */
	@Override
	public double calcularSalario()
	{
		double salario = sueldoFijo+calcularBono()+sueldoFijo*porcentajeAdicional(nivel);
		return salario;
	}
/**
 * Este es el metodo que nos ayuda a obtener acceso al nivel del ingenierio
 * @return un int indicando el nivel
 */
	public int getNivel() {
		return nivel;
	}
	/**
	 * Este es el metodo que nos ayuda a modificar al nivel del ingenierio
	 * @return un int indicando el nivel
	 */
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}
}
