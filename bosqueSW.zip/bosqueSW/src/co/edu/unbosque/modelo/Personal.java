package co.edu.unbosque.modelo;

import java.io.Serializable;

/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
public abstract class Personal implements Serializable{

	private String cedula;
	private String apellido;
	private String nombre;
	private String telefono;
	private String correo;
	private String direccion;
	private int anioIngreso;
	private char genero;
	/**
	 * 
	 * @param cedula , La cedula que le pondremos al personal  para identificarlo
	 * @param apellido, apellido que tendra nuestro personal
	 * @param nombre, nombre que tendra el personal
	 * @param telefono . telefono del personal
	 * @param correo , Correo que tendra el personal 
	 * @param direccion , Direccion que tendra el personal
	 * @param anioIngreso , A�o en el cual nuestro personal ingreso a la empresa
	 * @param genero , genero de nuestro personal
	 */

	public Personal(String cedula, String apellido, String nombre, String telefono, String correo, String direccion,
			int anioIngreso, char genero) {
		super();
		this.cedula = cedula;
		this.apellido = apellido;
		this.nombre = nombre;
		this.telefono = telefono;
		this.correo = correo;
		this.direccion = direccion;
		this.anioIngreso = anioIngreso;
		this.genero = genero;
	}
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public int getAnioIngreso() {
		return anioIngreso;
	}
	public void setAnioIngreso(int anioIngreso) {
		this.anioIngreso = anioIngreso;
	}
	public char getGenero() {
		return genero;
	}
	public void setGenero(char genero) {
		this.genero = genero;
	}

	public void verificarCorreo(String correo)
	{

	}

	public abstract double calcularSalario();

}