package co.edu.unbosque.controller;
/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
public class Launcher {
/**
 * Esta es la clase de la cual crearemos a nuestro controlador
 */

	public static void main(String[] args) {
		Controller c = new Controller();
	}
}
