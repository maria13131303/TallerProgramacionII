package co.edu.unbosque.modelo;
/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
/**
 * Esta es la clase del cliente donde se le pondra los atributos necesarios
 */
public class Cliente {
	/**
	 * Declararemos un nombre, cedula y monto  , que son los datos necesarios del cliente
	 */
	String nombre;
	String cedula;
	double monto;
	/**
	 * Este es el constructor de cliente 
	 * @param nombre , nombre del cliente
	 * @param cedula, cedula del cliente
	 * @param monto, monto que el cliente pagara
	 */
	public Cliente(String nombre, String cedula, double monto) {
		super();
		this.nombre = nombre;
		this.cedula = cedula;
		this.monto = monto;
	}
	/**
	 * Este es el metodo para obtener el nombre del cliente
	 * @return Nos devolvera un String con el nombre 
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Este es el metodo que nos permitira modificar el  nombre del cliente para asignarle uno nuevo
	 * <b> pre </b> El cliente debera tener un nombre y estar registrado
	 * @param nombre del cliente
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * Este es el metodo para obtener la cedula del cliente, con la que lo identificaremos
	 * @return Nos devolvera un String con la cedula del cliente 
	 */
	public String getCedula() {
		return cedula;
	}
	/**
	 * Este es el metodo que nos permitira modificar la cedula del cliente para asignarle una nuevo
	 * <b> pre </b> El cliente debera tener una cedula y estar registrado
	 * @param cedula del cliente
	 */
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	/**
	 * Este es el metodo que nos permite tener acceso al monto del cliente
	 * @return un double con el valor del monto
	 */
	public double getMonto() {
		return monto;
	}
	/**
	 * Este es el metodo que nos permite modificar el monto de el cliente
	 * <b> pre </b> El cliente debera tener un monto y estar registrado
	 * @param monto que ya debera tener el cliente
	 */
	public void setMonto(double monto) {
		this.monto = monto;
	}
/**
 * Este metodo nos ayuda a verificar que el monto esta en el rango definido de 500000 a 2000000
 * @return si el monto esta correcto nos retornara true de no ser asi false
 */
	public boolean verificarMonto()
	{
		boolean correcto = true;
		if (monto<500000 || monto>2000000) {
			correcto = false;
		}
		return correcto;
	}
}
