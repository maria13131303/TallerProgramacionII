package co.edu.unbosque.modelo;
/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */
import java.util.ArrayList;

public class PersonalComision extends Personal
{
	/**
	 * Aqui tenemos una variable estatica de 1100000 para salario minimo del personal de comision
	 */
	
	public static double MINIMO  = 1100000;
	int numClientes;
	/**
	 * Se declara el arrayList de clientes
	 */
	ArrayList<Cliente> clientes;
	/**
	 * 
	* @param cedula , La cedula que le pondremos al personal  para identificarlo
	 * @param apellido, apellido que tendra nuestro personal
	 * @param nombre, nombre que tendra el personal
	 * @param telefono . telefono del personal
	 * @param correo , Correo que tendra el personal 
	 * @param direccion , Direccion que tendra el personal
	 * @param anioIngreso , A�o en el cual nuestro personal ingreso a la empresa
	 * @param genero , genero de nuestro personal
	 * @param numClientes , numero de clientes que se le agregaran al personal de comision y de los cuales dependera su salario
	 */
	public PersonalComision(String cedula, String apellido, String nombre, String telefono, String correo,
			String direccion, int anioIngreso, char genero, int numClientes) {
		super(cedula, apellido, nombre, telefono, correo, direccion, anioIngreso, genero);
		this.numClientes = numClientes;
		clientes = new ArrayList<Cliente>();
	}
	/**
	 * El salario del personal de comision se calcula en base al minimo  y se le va sumando el monto de cada cliente que tiene el personal
	
	 */
	@Override
	public double calcularSalario() {
		double salario = MINIMO;
		double monto = 0;
		numClientes = clientes.size();
		for (int i = 0; i < clientes.size(); i++) {
			monto += clientes.get(i).getMonto()*clientes.size();
		}
		if (monto>=MINIMO) 
		{
			return monto;
		}
		else
		{
		return salario;
		}
	}
/**
 * Este metodo nos ayuda a obtener el numero de clientes  que tiene el personal de comision
 * @return un entero que nos indica la cantidad de clientes
 */
	public int getNumClientes() {
		return numClientes;
	}

	public void setNumClientes(int numClientes) {
		this.numClientes = numClientes;
	}

	public ArrayList<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(ArrayList<Cliente> clientes) {
		this.clientes = clientes;
	}
}
