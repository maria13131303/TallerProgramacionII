package co.edu.unbosque.modelo;
/**
 * 
 * @author Diego Fernando Garnica Ortiz
 * @author Juan David Florez Godoy
 * @author Maria Victoria Lopez Lopez
 */

/**
 * Esta es la clase de Ingenierio seniot
 *
 */
public class IngenieroSenior extends PersonalSalarioFijo{
	int numVentas;
	/**
	 * 
	 * @param cedula , La cedula que le pondremos al personal  para identificarlo
	 * @param apellido, apellido que tendra nuestro personal
	 * @param nombre, nombre que tendra el personal
	 * @param telefono . telefono del personal
	 * @param correo , Correo que tendra el personal 
	 * @param direccion , Direccion que tendra el personal
	 * @param anioIngreso , A�o en el cual nuestro personal ingreso a la empresa
	 * @param genero , genero de nuestro personal
	 * @param numVentas , el numero de ventas de la cual dependera su salario
	 */
	public IngenieroSenior(String cedula, String apellido, String nombre, String telefono, String correo,
			String direccion, int anioIngreso, char genero, int numVentas) {
		super(cedula, apellido, nombre, telefono, correo, direccion, anioIngreso, genero);
		this.numVentas = numVentas;
	}
	/**
	 * Este es el metodo que nos ayuda a calcular el porcentaje adicional del ingeniero Senior
	 *  De 1 a 5 ventas: 10% m�s 
	 *  De 6 a 10 ventas: 15% m�s 
	 *  De 10 a 20 ventas: 20% m�s 
	 *  M�s de 21 ventas: 30% m�s
	 */
	@Override
	public double porcentajeAdicional(int numVentas) {
		double porcentaje = 0;

		if (numVentas>=1&&numVentas<=5) 
		{
			porcentaje = 0.10;
		}
		if (numVentas>5&&numVentas<10) 
		{
			porcentaje = 0.15;
		}
		if (numVentas>=10&&numVentas<=20) 
		{
			porcentaje = 0.20;
		}
		if (numVentas>=21) 
		{
			porcentaje = 0.30;
		}
		return porcentaje;
	}
/**
 * Este es el metodo que nos permite calcular el salario y agregarle los porcentajes adicionales
 */
	@Override
	public double calcularSalario() {
		double salario = SUELDO_FIJO+calcularBono()+SUELDO_FIJO*porcentajeAdicional(numVentas);
		return salario;
	}
/**
 * Este es el metodo que nos permite obtener el numero de ventas que ha realizado el ingeniero
 * @return un entero con el numero de ventas
 */
	public int getNumVentas() {
		return numVentas;
	}
	/**
	 * Este es el metodo que nos permite modificar el numero de ventas
	 * @param numVentas numero de ventas que ya tenia el ingeniero
	 */

	public void setNumVentas(int numVentas) {
		this.numVentas = numVentas;
	}
}
