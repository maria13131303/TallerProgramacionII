package controlador;

import vista.FrameP;

public class Inicio {

	public static void main(String[] args) {
		FrameP f = new FrameP();
	}

}
