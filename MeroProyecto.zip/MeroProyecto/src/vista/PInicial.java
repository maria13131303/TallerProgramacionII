package vista;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.text.IconView;

public class PInicial extends JPanel implements ActionListener {

	FrameP f;
	JLabel fondo, fVer, fDespedir, fRegV, fEliV, fCon, fAgrE, fAgrC, fEliC, fRestaurar;
	JButton btnVer, btnDes, btnRegV, btnEliV, btnCon, btnAgrE, btnAgrC, btnEliC, btnRes;
	
	public PInicial (FrameP f) {
		this.f = f;
		setLayout(null);
		setBounds(-5,0,995,515);
		setVisible(true);
		agregarComponentes();
		bloquear();
	}
	
	private void agregarComponentes() {
		
		btnVer = new JButton();
		btnVer.setBounds(520, 155, 200, 49);
		btnVer.setContentAreaFilled(false);
		btnVer.setBorderPainted(false);
		btnVer.addActionListener(this);
		btnVer.setActionCommand("ver");
		add(btnVer);
		
		fVer = new JLabel();
		fVer.setBounds(510, 145, 220, 69);
		add(fVer);

		btnDes = new JButton();
		btnDes.setBounds(740, 155, 200, 49);
		btnDes.setContentAreaFilled(false);
		btnDes.setBorderPainted(false);
		btnDes.addActionListener(this);
		btnDes.setActionCommand("des");
		add(btnDes);
		
		fDespedir = new JLabel();
		fDespedir.setBounds(730, 145, 220, 69);
		add(fDespedir);
		
		btnRegV = new JButton();
		btnRegV.setBounds(520, 225, 200, 49);
		btnRegV.setContentAreaFilled(false);
		btnRegV.setBorderPainted(false);
		btnRegV.addActionListener(this);
		btnRegV.setActionCommand("regV");
		add(btnRegV);
		
		fRegV = new JLabel();
		fRegV.setBounds(510, 215, 220, 69);
		add(fRegV);

		btnEliV = new JButton();
		btnEliV.setBounds(740, 225, 200, 49);
		btnEliV.setContentAreaFilled(false);
		btnEliV.setBorderPainted(false);
		btnEliV.addActionListener(this);
		btnEliV.setActionCommand("eliV");
		add(btnEliV);
		
		fEliV = new JLabel();
		fEliV.setBounds(730, 215, 220, 69);
		add(fEliV);

		btnCon = new JButton();
		btnCon.setBounds(605, 295, 250, 49);
		btnCon.setContentAreaFilled(false);
		btnCon.setBorderPainted(false);
		btnCon.addActionListener(this);
		btnCon.setActionCommand("con");
		add(btnCon);
		
		fCon = new JLabel();
		fCon.setBounds(590, 285, 280, 69);
		add(fCon);

		btnAgrE = new JButton();
		btnAgrE.setBounds(51, 394, 220, 55);
		btnAgrE.setContentAreaFilled(false);
		btnAgrE.setBorderPainted(false);
		btnAgrE.addActionListener(this);
		btnAgrE.setActionCommand("agrE");
		add(btnAgrE);
		
		ImageIcon iconAgrE = new ImageIcon("data/fonAgregarE.png");
		fAgrE = new JLabel(iconAgrE);
		fAgrE.setBounds(41, 384, 240, 74);
		add(fAgrE);

		btnAgrC = new JButton();
		btnAgrC.setBounds(277, 394, 220, 55);
		btnAgrC.setContentAreaFilled(false);
		btnAgrC.setBorderPainted(false);
		btnAgrC.addActionListener(this);
		btnAgrC.setActionCommand("agrC");
		add(btnAgrC);
		
		ImageIcon iconAgrC = new ImageIcon("data/fonAgregarC.png");
		fAgrC = new JLabel(iconAgrC);
		fAgrC.setBounds(267, 384, 240, 74);
		add(fAgrC);

		btnEliC = new JButton();
		btnEliC.setBounds(503, 394, 220, 55);
		btnEliC.setContentAreaFilled(false);
		btnEliC.setBorderPainted(false);
		btnEliC.addActionListener(this);
		btnEliC.setActionCommand("eliC");
		add(btnEliC);
		
		ImageIcon iconEliC = new ImageIcon("data/fonEliminarC.png");
		fEliC = new JLabel(iconEliC);
		fEliC.setBounds(493, 384, 240, 74);
		add(fEliC);

		btnRes = new JButton();
		btnRes.setBounds(728, 394, 220, 55);
		btnRes.setContentAreaFilled(false);
		btnRes.setBorderPainted(false);
		btnRes.addActionListener(this);
		btnRes.setActionCommand("res");
		add(btnRes);
		
		ImageIcon iconRes = new ImageIcon("data/fonRestaurar.png");
		fRestaurar = new JLabel(iconRes);
		fRestaurar.setBounds(718, 384, 240, 74);
		add(fRestaurar);
		
		ImageIcon iconFondo = new ImageIcon("data/fondo.png");
		fondo = new JLabel(iconFondo);
		fondo.setBounds(0,0,1000,495);
		add(fondo);
	}

	public void bloquear () {
		ImageIcon iconVerb = new ImageIcon("data/fVerb.png");
		fVer.setIcon(iconVerb);
		btnVer.setVisible(false);
		
		ImageIcon iconDesb = new ImageIcon("data/fDesb.png");
		fDespedir.setIcon(iconDesb);
		btnDes.setVisible(false);
		
		ImageIcon iconRegb = new ImageIcon("data/fRegb.png");
		fRegV.setIcon(iconRegb);
		btnRegV.setVisible(false);
		
		ImageIcon iconElib = new ImageIcon("data/fElib.png");
		fEliV.setIcon(iconElib);
		btnEliV.setVisible(false);
		
		ImageIcon iconConb = new ImageIcon("data/fConb.png");
		fCon.setIcon(iconConb);
		btnCon.setVisible(false);
	}
	
	public void desbloquear () {
		ImageIcon iconVer = new ImageIcon("data/fonVer.png");
		fVer.setIcon(iconVer);
		btnVer.setVisible(true);
		
		ImageIcon iconDes = new ImageIcon("data/fonDespedir.png");
		fDespedir.setIcon(iconDes);
		btnDes.setVisible(true);
		
		ImageIcon iconRegV = new ImageIcon("data/fonRegistrarV.png");
		fRegV.setIcon(iconRegV);
		btnRegV.setVisible(true);
		
		ImageIcon iconEliV = new ImageIcon("data/fonEliminarV.png");
		fEliV.setIcon(iconEliV);
		btnEliV.setVisible(true);

		ImageIcon iconCon = new ImageIcon("data/fonConsulta.png");
		fCon.setIcon(iconCon);
		btnCon.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		String accion = arg0.getActionCommand();
		
		if (accion == "ver") {
			f.getPi().setVisible(false);
			f.setTitle("BosqueSW - Agregar Empleado");
			ImageIcon btn = new ImageIcon("data/actualizarb.png");
			f.getPde().fRegistrar.setIcon(btn);
			f.getPde().btnReg.setVisible(false);
			ImageIcon iconTit = new ImageIcon("data/tituloDatos.png");
			f.getPde().titulo.setIcon(iconTit);
			f.getPde().mostrarEdit();
			f.getPde().setVisible(true);
			System.out.println("Ver");
		}
		
		if (accion == "des") {
			int dialogButton = JOptionPane.showConfirmDialog (null, "�Est� seguro de despedir este empleado?","ADVERTENCIA",JOptionPane.YES_NO_OPTION);

			if(dialogButton == JOptionPane.YES_OPTION) {
			System.exit(0);}else {remove(dialogButton);}
			System.out.println("Despedir");
		}
		
		if (accion == "regV") {
			System.out.println("Registrar Venta");
		}
		
		if (accion == "eliV") {
			System.out.println("Eliminar Venta");
		}
		
		if (accion == "con") {
			System.out.println("Consultar Salario");
		}
		
		if (accion == "agrE") {
			
			f.getPi().setVisible(false);
			f.setTitle("BosqueSW - Agregar Empleado");
			ImageIcon btn = new ImageIcon("data/registrar.png");
			f.getPde().fRegistrar.setIcon(btn);
			f.getPde().btnReg.setVisible(true);
			ImageIcon iconTit = new ImageIcon("data/tituloCompleta.png");
			f.getPde().titulo.setIcon(iconTit);
			f.getPde().ocultarEdit();
			f.getPde().setVisible(true);
			System.out.println("Agregar Empleado");
		}
		
		if (accion == "agrC") {
			
			f.getPi().setVisible(false);
			f.setSize(600, 495);
			f.setLocationRelativeTo(null);
			f.setTitle("BosqueSW - Agregar Cliente");
			f.getPdc().setVisible(true);
			System.out.println("Agregar Cliente");
		}
		
		if (accion == "eliC") {
			bloquear();
			System.out.println("Eliminar Cliente");
		}
		
		if (accion == "res") {
			desbloquear();
			System.out.println("Restaurar sistema");
		}
	}
}
