package co.edu.unbosque.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import co.edu.unbosque.controller.Controller;

public class PDatosCliente extends JPanel implements ActionListener {

	FrameP f;
	JLabel fondo, fRegistrar, fCancelar;
	JButton btnReg, btnCan;
	JTextField nom, ape, ced;
	Controller c;
	public PDatosCliente (FrameP f, Controller co) {
		c = co;
		this.f = f;
		setLayout(null);
		setBounds(-5, 0, 595, 515);
		agregarComponentes();
	}
	
	private void agregarComponentes() {

		nom = new JTextField();
		nom.setBounds(225, 145, 300, 35);
		add(nom);
		
		ape = new JTextField();
		ape.setBounds(225, 205, 300, 35);
		add(ape);
		
		ced = new JTextField();
		ced.setBounds(355, 265, 170, 35);
		add(ced);
		
		btnReg = new JButton();
		btnReg.setBounds(190, 334, 220, 55);
		btnReg.setContentAreaFilled(false);
		btnReg.setBorderPainted(false);
		btnReg.addActionListener(this);
		btnReg.setActionCommand("reg");
		add(btnReg);

		ImageIcon iconReg = new ImageIcon("data/registrar.png");
		fRegistrar = new JLabel(iconReg);
		fRegistrar.setBounds(180, 324, 240, 74);
		add(fRegistrar);

		btnCan = new JButton();
		btnCan.setBounds(190, 394, 220, 55);
		btnCan.setContentAreaFilled(false);
		btnCan.setBorderPainted(false);
		btnCan.addActionListener(this);
		btnCan.setActionCommand("can");
		add(btnCan);

		ImageIcon iconCan = new ImageIcon("data/cancelar.png");
		fCancelar = new JLabel(iconCan);
		fCancelar.setBounds(180, 384, 240, 74);
		add(fCancelar);
		
		ImageIcon iconFon = new ImageIcon("data/fondoDatosCliente.png");
		fondo = new JLabel(iconFon);
		fondo.setBounds(0, 0, 600, 495);
		add(fondo);
	}
	
	

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String accion = arg0.getActionCommand();
		
		if (accion == "can") {
			f.getPdc().setVisible(false);
			f.setSize(995, 515);
			f.setLocationRelativeTo(null);
			f.setTitle("BosqueSW");
			f.getPi().setVisible(true);
		}
		if (accion == "reg") {
			
		}
		
	}
}
